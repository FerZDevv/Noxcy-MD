function _0x3c22(_0xf24539, _0x3e92ea) {
    const _0x265813 = _0x2658();
    return _0x3c22 = function (_0x3c229a, _0x298759) {
        _0x3c229a = _0x3c229a - 0x16f;
        let _0x3d5909 = _0x265813[_0x3c229a];
        return _0x3d5909;
    }, _0x3c22(_0xf24539, _0x3e92ea);
}
const _0x3244ae = _0x3c22;
(function (_0x62c902, _0x33f29a) {
    const _0x78a7f6 = _0x3c22, _0xa01693 = _0x62c902();
    while (!![]) {
        try {
            const _0x58ae89 = parseInt(_0x78a7f6(0x17a)) / 0x1 * (-parseInt(_0x78a7f6(0x18d)) / 0x2) + parseInt(_0x78a7f6(0x175)) / 0x3 * (-parseInt(_0x78a7f6(0x18c)) / 0x4) + -parseInt(_0x78a7f6(0x1a3)) / 0x5 * (parseInt(_0x78a7f6(0x1a2)) / 0x6) + parseInt(_0x78a7f6(0x185)) / 0x7 * (-parseInt(_0x78a7f6(0x1aa)) / 0x8) + parseInt(_0x78a7f6(0x1a8)) / 0x9 + parseInt(_0x78a7f6(0x17e)) / 0xa + -parseInt(_0x78a7f6(0x1a9)) / 0xb * (-parseInt(_0x78a7f6(0x19f)) / 0xc);
            if (_0x58ae89 === _0x33f29a)
                break;
            else
                _0xa01693['push'](_0xa01693['shift']());
        } catch (_0x2bd0b1) {
            _0xa01693['push'](_0xa01693['shift']());
        }
    }
}(_0x2658, 0x6e0c0));
import {
    watchFile,
    unwatchFile
} from 'fs';
import _0x8b27bc from 'chalk';
import { fileURLToPath } from 'url';
let d = new Date(new Date() + 0x36ee80), locale = 'id', weton = [
        _0x3244ae(0x198),
        'ᴘᴏɴ',
        _0x3244ae(0x174),
        'ᴋʟɪᴡᴏɴ',
        _0x3244ae(0x1ad)
    ][Math[_0x3244ae(0x186)](d / 0x50ae4c0) % 0x5], week = d[_0x3244ae(0x19e)](locale, { 'weekday': 'long' }), date = d[_0x3244ae(0x19e)](locale, {
        'day': _0x3244ae(0x17b),
        'month': 'long',
        'year': _0x3244ae(0x17b)
    });
global[_0x3244ae(0x1a4)] = [
    [
        '6285878075754',
        _0x3244ae(0x183),
        !![]
    ],
    [
        _0x3244ae(0x18e),
        'ᯓ★\x20Nᴏxᴄʏ\x20-\x20MD\x20(ʙᴏᴛᴢ)',
        !![]
    ]
], global['mods'] = [_0x3244ae(0x188)], global[_0x3244ae(0x17d)] = [
    _0x3244ae(0x188),
    _0x3244ae(0x18e)
], global[_0x3244ae(0x195)] = _0x3244ae(0x188), global[_0x3244ae(0x193)] = {
    'nrtm': _0x3244ae(0x19c),
    'lann': 'https://api.betabotz.eu.org'
}, global['APIKeys'] = { 'https://api.betabotz.eu.org': 'fyUnm7GI' }, global[_0x3244ae(0x16f)] = _0x3244ae(0x1ae), global[_0x3244ae(0x1a5)] = 'f2707993c4db1ce11209da14', global[_0x3244ae(0x176)] = 0x45, global['namebot'] = _0x3244ae(0x1af), global[_0x3244ae(0x1a1)] = _0x3244ae(0x17f), global[_0x3244ae(0x1a0)] = _0x3244ae(0x170), global[_0x3244ae(0x197)] = _0x3244ae(0x172) + week + '\x20' + date, global[_0x3244ae(0x177)] = _0x3244ae(0x1a7), global[_0x3244ae(0x190)] = _0x3244ae(0x187), global['cr'] = _0x3244ae(0x196), global[_0x3244ae(0x1ac)] = 'https://www.instagram.com/ferzdevxd', global[_0x3244ae(0x191)] = _0x3244ae(0x189), global[_0x3244ae(0x173)] = _0x3244ae(0x19a), global[_0x3244ae(0x17c)] = 'https://telegra.ph/file/6ff2b6ce8e6c1d3348549.jpg', global['jpg'] = _0x3244ae(0x194), global[_0x3244ae(0x182)] = '`', global[_0x3244ae(0x181)] = _0x3244ae(0x178), global['eror'] = _0x3244ae(0x1ab), global[_0x3244ae(0x18f)] = '⌛', global[_0x3244ae(0x184)] = '🤭', global['done'] = '✅', global[_0x3244ae(0x18a)] = '❌', global[_0x3244ae(0x171)] = '🔥', global[_0x3244ae(0x18b)] = 0x45, global[_0x3244ae(0x19b)] = '2';
function _0x2658() {
    const _0x487a12 = [
        '67519GVzcGy',
        'numeric',
        'NSfer',
        'prems',
        '726380IaBrFY',
        'ᯓ★\x20𝐍𝐨𝐱𝐜𝐲\x20-\x20𝐌𝐃\x0a\x0a\x0aᴘᴏᴡᴇʀᴇᴅ\x20ʙʏ:\x0a\x0aғ\x0aᴇ\x0aʀ\x0aᴢ\x0aᴅ\x0aᴇ\x0aᴠ\x0a\x0ax\x0aᴅ',
        'url',
        'wait',
        'NSprf',
        'FᴇʀZDᴇᴠᴠ',
        'dmoji',
        '21427MEhzXq',
        'floor',
        'ᴘ\x20ᴏ\x20ᴡ\x20ᴇ\x20ʀ\x20ᴇ\x20ᴅ\x20\x20ʙ\x20ʏ\x20\x20ғ\x20ᴇ\x20ʀ\x20ᴢ\x20ᴅ\x20ᴇ\x20ᴠ\x20ᴠ',
        '6285878075754',
        'https://whatsapp.com/channel/0029VaBl0VOAInPsCK1JJG3A',
        'error',
        'multiplier',
        '31648IeAcTW',
        '6pMnDJW',
        '62895355636551',
        'rwait',
        'NSferdev',
        'NSgc',
        'TFjWx',
        'APIs',
        'https://telegra.ph/file/42f914b2329902f68597c.jpg',
        'noowner',
        '©\x20Copyright\x20VerZDevv\x20-\x202024',
        'botdate',
        'ᴘᴀʜɪɴɢ',
        'now',
        'https://telegra.ph/file/b1c671088003f3ddd9937.jpg',
        'maxwarn',
        'https://fg-nrtm.ddns.net',
        'log',
        'toLocaleDateString',
        '19015944DWlfCY',
        'author',
        'packname',
        '6SMHBwF',
        '601915zBdZzM',
        'owner',
        'lolkey',
        '?update=',
        'ᯓ★\x20Nᴏxᴄʏ\x20MD\x20Bᴏᴛᴢ\x20WʜᴀᴛsAᴘᴘ\x0aFᴇʀZDᴇᴠᴠ',
        '1705410cOCaNP',
        '11QIdpmf',
        '592pSnHya',
        '_ᴇʀʀᴏʀ,\x20ᴋᴇsᴀʟᴀʜᴀɴ\x20ᴛɪᴅᴀᴋ\x20ᴛᴇʀᴅᴜɢᴀ_',
        'NSig',
        'ʟᴇɢɪ',
        'fyUnm7GI',
        'ᯓ★\x20𝐍𝐨𝐱𝐜𝐲\x20-\x20𝐌𝐃',
        'lann',
        'VᴇʀZDᴇᴠᴠ',
        'xmoji',
        'Day\x27s:\x20',
        'NSthumb',
        'ᴡᴀɢᴇ',
        '321tMNDNI',
        'limit',
        'NSnama',
        '*⌛\x20_ʟᴏᴀᴅɪɴɢ..._*\x0a>\x20*▰▰▰▱▱▱▱▱*',
        'cbPQH'
    ];
    _0x2658 = function () {
        return _0x487a12;
    };
    return _0x2658();
}
let file = fileURLToPath(import.meta[_0x3244ae(0x180)]);
watchFile(file, () => {
    const _0x514634 = _0x3244ae, _0x2c3b56 = {
            'TFjWx': function (_0x3a133e, _0x14634e) {
                return _0x3a133e(_0x14634e);
            },
            'cbPQH': 'Update\x20\x27config.js\x27'
        };
    _0x2c3b56[_0x514634(0x192)](unwatchFile, file), console[_0x514634(0x19d)](_0x8b27bc['redBright'](_0x2c3b56[_0x514634(0x179)])), import(file + _0x514634(0x1a6) + Date[_0x514634(0x199)]());
});