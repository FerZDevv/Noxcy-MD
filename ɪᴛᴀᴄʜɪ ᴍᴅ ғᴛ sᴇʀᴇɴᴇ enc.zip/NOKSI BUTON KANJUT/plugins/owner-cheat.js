let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
        global.db.data.users[m.sender].diamond = 999999999999
        global.db.data.users[m.sender].coin = 999999999999
        global.db.data.users[m.sender].exp = 999999999999
        global.db.data.users[m.sender].bank = 999999999999
        global.db.data.users[m.sender].level = 999999999999
        m.reply(`   [ *P R E M I U M* 👑]\n\n*Selamat Kamu Mendapatkan*:\n*Koin:* 999999999999\n*Diamond:* 999999999999\n*Exp:* 999999999999`)
}
handler.command = /^(cheat)$/i
handler.premium = true
handler.cooldown = 1
export default handler