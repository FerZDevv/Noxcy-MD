/*Created By FerZDevv
Wm gua jangan di hapus anjg*/
let handler = async (m, {conn}) => {
let audio = {
    audio: {url: 'https://pomf2.lain.la/f/xe3qczl.mp3'},
    mimetype: 'audio/mp4',
    ptt: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: namebot,
        body: botdate,
        sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
        thumbnail: await (await conn.getFile('https://telegra.ph/file/d6f44478fd2ece636755e.jpg')).data,
        renderLargerThumbnail: true
      }
    }
  };

  conn.sendMessage(m.chat, audio, { quoted: m })
}
handler.customPrefix = /^(assalamualaikum|salam|asalamualaikum|assalam|asalam|salam|salom|shalom)$/i
handler.command = new RegExp

export default handler