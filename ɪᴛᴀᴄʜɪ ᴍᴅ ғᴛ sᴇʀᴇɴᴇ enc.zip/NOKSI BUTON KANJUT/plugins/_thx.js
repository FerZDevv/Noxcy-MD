let handler = async(m, {conn, text, args}) => {

conn.sendPresenceUpdate('recording', m.chat)
m.reply(`_Sama sama_`)
}

handler.customPrefix = /^(terimakasih|makasih|thx|thxx|thanks)$/i
handler.command = new RegExp

export default handler