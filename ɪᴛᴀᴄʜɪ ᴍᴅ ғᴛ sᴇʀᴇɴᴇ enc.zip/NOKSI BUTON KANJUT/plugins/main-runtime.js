let handler = async (m, { conn, args, usedPrefix, command }) => {
	
	let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
let muptime = clockString(_muptime)

let fer = `乂 *R U N T I M E*\n•> ${muptime}`
let fake = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: `𝙽𝙾𝚇𝙲𝚈 𝙼𝙳`, participant: '0@s.whatsapp.net' }, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 1, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `𝙿𝚁𝙾𝙹𝙴𝙲𝚃 𝙵𝙴𝚁𝚉𝙳𝙴𝚅𝚅` }}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD" }}}}
const Pareploy = (teks) => { alice.sendMessage(m.chat, { text: teks, contextInfo:{ forwardingScore: 2000000000, isForwarded: false }}, { quoted : repPy })}
conn.sendMessage(m.chat, {
text: fer,
contextInfo: {
externalAdReply: {
title: namebot,
body: ``,
showAdAttribution: true,
mediaType: 1,
sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
thumbnailUrl: jpg,
renderLargerThumbnail: false
}}
}, {quoted: fake})
}

handler.help = ['runtime']
handler.tags = ['main']
handler.command = ['runtime', 'uptime']
export default handler
function clockString(ms) {
	let d = isNaN(ms) ? "--" : Math.floor(ms / 86400000);
	let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000) % 24;
	let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
	let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
	return [d, " *Hari* ", h, " *Jam* ", m, " *Menit* ", s, " *Detik* "]
		.map((v) => v.toString().padStart(2, 0))
		.join("");
}