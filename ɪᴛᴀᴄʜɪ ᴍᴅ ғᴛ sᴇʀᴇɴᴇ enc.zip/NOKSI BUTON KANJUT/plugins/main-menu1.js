import { promises } from 'fs'
import fs from 'fs'
import fetch from 'node-fetch'
let handler = async (m, { conn, command, usedPrefix }) => {

let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
let str = `
*\`🍁 Wᴇʟᴄᴏᴍᴇ ᴛᴏ ᴛʜᴇ ᴅᴀsʜʙᴏᴀʀᴅ ʙᴏᴛᴢ Nᴏxᴄʏ - MD ! 🍁\`*

*⏤͟͟͞͞ᵡ  INFO BOT  ᵡ͟͟͞͞⏤*
   ⛩️ *ɴᴀᴍᴇ ʙᴏᴛ* : Nᴏxᴄʏ - MD
   ⛩️ *ᴄʀᴇᴀᴛᴏʀ* : FᴇʀᴢDᴇᴠᴠ
   ⛩️ *ᴘʟᴀᴛғᴏʀᴍ* : ʟɪɴᴜx
   ⛩️ *ᴛʏᴘᴇ sᴄʀɪᴘᴛ* : ᴘʟᴜɢɪɴs
   ⛩️ *ᴜᴘᴛɪᴍᴇ* : ${muptime}  

> ɪ ᴀᴍ ᴀɴ ᴀᴜᴛᴏᴍᴀᴛᴇᴅ ᴡʜᴀᴛsᴀᴘᴘ ʙᴏᴛ ᴛʜᴀᴛ ᴄᴀɴ ʜᴇʟᴘ ᴅᴏ sᴏᴍᴇᴛʜɪɴɢ, sᴇᴀʀᴄʜ ᴀɴᴅ ɢᴇᴛ ᴅᴀᴛᴀ ᴏʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴠɪᴀ ᴡʜᴀᴛsᴀᴘᴘ ☘.
> ᴘʟᴇᴀsᴇ ᴜɴᴅᴇʀsᴛᴀɴᴅ, ᴛʜɪs sᴄʀɪᴘᴛ sᴛɪʟʟ ʜᴀs ʟᴏᴛs ᴏғ ᴇʀʀᴏʀs ʙᴇᴄᴀᴜsᴇ ɪᴛ ɪs sᴛɪʟʟ ɪɴ ᴛʜᴇ ᴅᴇᴠᴇʟᴏᴘᴍᴇɴᴛ sᴛᴀɢᴇ.

> *乂 M E N U*
🫧 .ᴀʟʟᴍᴇɴᴜ
🫧 .ᴏᴡɴᴇʀ
ᴛᴏ ᴅɪsᴘʟᴀʏ ᴀʟʟ ᴄᴍᴅ ᴛʏᴘᴇ *.ᴀʟʟᴍᴇɴᴜ*

> *#ʙᴇ ᴀ sᴍᴀʀᴛ ᴜsᴇʀ*
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ : FᴇʀZDᴇᴠᴠ
`
let bjir = 'https://telegra.ph/file/146faebc8f0eb99263222.png'
let apalah = fs.readFileSync('./vn/tucadonca.mp3') 
await conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'JPY',
      amount1000: '99999999',
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
      extendedTextMessage: {
      text: str,
      contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
      
      conn.sendFile(m.chat, apalah, 'crash.mp3', null, m)
}
handler.command = ('menu1')

export default handler

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'ᴅ ', h, 'ʜ ', m, 'ᴍ ', s, 's '].map(v => v.toString().padStart(1, 0)).join('')
}